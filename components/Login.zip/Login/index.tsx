"use client";

import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import logo from "../../assets/via_green_logo3.png";
import { useRouter } from "next/navigation";
import { storeTokens } from "@/api/auth/tokens";
import { handle_Auth } from "@/api/controller/auth";

interface LoginProps {
  setIsAuthenticated: (value: boolean) => void;
}

const Login: React.FC<LoginProps> = ({ setIsAuthenticated }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const router = useRouter();

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

 const handleLogin = async () => {
  if (!email.trim() || !password.trim()) {
    alert("Please fill in all fields.");
    return;
  }

  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  try {
    setLoading(true);

    const rs = await handle_Auth.login({ email, password });

    console.log("RAW LOGIN RESPONSE:", rs);

    //  HANDLE ADMIN + CLIENT LOGIN
  
    const token = rs?.token;
    // Admin → rs.data
    // Client → rs.user
    const user = rs?.data || rs?.user;

    // Detect role
    const role =
      rs?.data?.role?.name ||     // Admin (example: "Admin")
      rs?.user?.role_name ||      // Client (example: "Collector")
      user?.role_name ||          // Fallback
      null;

    console.log("TOKEN:", token);
    console.log("USER:", user);
    console.log("ROLE:", role);

    if (!token || !user) {
      alert("Invalid email or password.");
      return;
    }
    localStorage.setItem("access_token", token);
    localStorage.setItem("user", JSON.stringify(user));

    if (role) {
      localStorage.setItem("role", role.toLowerCase());
    }

    //  For CLIENT login → store first_name
    if (user?.first_name) {
      localStorage.setItem("client_name", user.first_name);
    }

    setIsAuthenticated(true);
    router.push("/");

  } catch (error) {
    console.error("LOGIN ERROR:", error);
    alert("Login failed. Try again.");
  } finally {
    setLoading(false);
  }
};


  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-6 overflow-hidden">
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0"
      >
        <source src="/bg_video/back_gr.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-black/30 z-10"></div>

      <Card className="relative z-20 w-full max-w-md bg-white/10 backdrop-blur-2xl border-white/20 shadow-xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-3">
            <Image src={logo} alt="Logo" className="h-12 w-48 object-contain" />
          </div>
        </CardHeader>

        <CardContent className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-white">
              Email
            </Label>
            <Input
              id="email"
              className="bg-white/20 text-white border-white/30 placeholder:text-gray-300 mt-2"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">
              Password
            </Label>

            <div className="relative mt-2">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                className="bg-white/20 text-white border-white/30 placeholder:text-gray-300 pr-12"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/70 hover:text-white"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <Button
            onClick={handleLogin}
            disabled={loading}
            className="w-full bg-black hover:bg-yellow-700 text-white font-semibold py-2 rounded-lg disabled:opacity-50 cursor-pointer"
          >
            {loading && (
              <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
            )}
            {loading ? "Processing..." : "Login"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
