"use client";

import clsx from "clsx";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useEffect, useState } from "react";

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const ADMIN_ROLES = ["admin", "administrator"];

const Sidebar: React.FC<SidebarProps> = ({ isOpen, closeSidebar }) => {
  const pathname = usePathname();
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    const storedRole = localStorage.getItem("role");
    setRole(storedRole?.toLowerCase() ?? null);
  }, []);

  // Wait until role is loaded
  if (!role) return null;

  const isAdmin = ADMIN_ROLES.includes(role);

  const navItems = [
    { name: "Dashboard", path: "/" },
    { name: "All Reports", path: "/reports" },

    // ✅ Admin only
    ...(isAdmin
      ? [{ name: "Manage Reports", path: "/manage_reports" }]
      : []),
  ];

  return (
    <>
      {/* Mobile Overlay */}
      <div
        className={clsx(
          "fixed inset-0 z-20 md:hidden transition-opacity",
          isOpen ? "visible opacity-50 bg-black" : "invisible opacity-0"
        )}
        onClick={closeSidebar}
      />

      {/* Sidebar */}
      <aside
        className={clsx(
          "fixed md:static top-16 left-0 h-[calc(100%)] w-64 bg-white border-r border-gray-200 shadow-md z-30 transform transition-transform duration-300",
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <nav className="flex flex-col gap-3 mt-4 p-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              onClick={closeSidebar}
              className={clsx(
                "px-4 py-2 rounded-lg transition-colors text-gray-800 font-bold",
                pathname === item.path
                  ? "bg-blue-600 text-white"
                  : "hover:bg-gray-100"
              )}
            >
              {item.name}
            </Link>
          ))}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
