"use client";
import React, { useEffect, useState } from "react";
import { Pencil, Trash2, Search } from "lucide-react";

import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";

import { handle_waste_reports } from "@/api/controller/all_waste";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import jsPDF from "jspdf";

interface WasteItem {
  id: number;
  waste_type: string;
  quantity: number | string;
  location: string;
  status: string;
  waste_time: string;
  unit: string;
}

interface ManageReportsTableProps {
  data: Array<{ id: number }>;
}

const ManageReportsTable: React.FC<ManageReportsTableProps> = ({ data }) => {
  const [wasteData, setWasteData] = useState<WasteItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // SEARCH STATES
  const [searchTerm, setSearchTerm] = useState("");
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<boolean>(false);

  const [editConfirm, setEditConfirm] = useState<boolean>(false);
  const [editSelectedData, setEditSelectedData] = useState<any>({
    id: null,
    unit: "",
    quantity: "",
    status: "",
  });

  const [updateLoading, setUpdateLoading] = useState<boolean>(false);

  // FETCH API
  const handleData = async () => {
    try {
      if (!data || data.length === 0) {
        setLoading(false);
        return;
      }

      const rs = await handle_waste_reports.get_waste_reports_details({
        id: data[0].id,
      });

      setWasteData(rs?.wastes || []);
    } catch (error) {
      console.log("Error fetching waste data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleData();
  }, []);

  // FILTER LOGIC
  const filteredData = wasteData?.filter((item) => {
    const term = searchTerm.toLowerCase().trim();
    const itemDate = new Date(item.waste_time);

    // RANGE CHECK
    if (startDate && itemDate < new Date(startDate)) return false;
    if (endDate && itemDate > new Date(endDate)) return false;

    // SEARCH CONDITIONS
    return (
      item.waste_type?.toLowerCase().includes(term) ||
      item.quantity?.toString()?.toLowerCase().includes(term) ||
      item.location?.toLowerCase().includes(term) ||
      item.status?.toLowerCase().includes(term) ||
      itemDate.toDateString().toLowerCase().includes(term)
    );
  });



  const handleDownloadPDF = (rows: WasteItem[]) => {
    const doc = new jsPDF();
  
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
  
    let y = 10;
  
    rows.forEach((item, index) => {
      const line = `${index + 1}. ${item.waste_type} | ${item.quantity} ${
        item.unit
      } | ${item.location} | ${item.status} | ${new Date(
        item.waste_time
      ).toLocaleString()}`;
  
      doc.text(line, 10, y);
  
      y += 10;
      if (y > 280) {
        doc.addPage();
        y = 10;
      }
    });
  
    doc.save("WasteReports.pdf");
  };
  

  const handleDelete = async (id: number) => {
    const rs = await handle_waste_reports.delete_wastes(id);
    if (rs?.status === 200) {
      handleData();
      alert("Deleted Successfully");
    }
  };

  const handleEdit = async (editData: any) => {
    setUpdateLoading(true);
    const rs = await handle_waste_reports.edit_wastes(editData, data[0].id);

    if (rs?.status === 200) {
      setTimeout(() => {
        handleData();
        setEditConfirm(false);
        setUpdateLoading(false);
      }, 1500);
    } else {
      setUpdateLoading(false);
    }
  };

  return (
    <div className="w-full rounded-xl border p-4 bg-white mt-5">

      {/* SEARCH + RANGE + PDF */}
      <div className="w-full flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">

        {/* SEARCH */}
        <div className="w-full sm:max-w-sm relative">
          <Search className="absolute left-3 top-2.5 text-gray-500" size={20} />
          <input
            type="text"
            placeholder="Search type, qty, location, status, date"
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* DATE RANGE */}
        <div className="flex items-center gap-2">
          <input
            type="date"
            className="border rounded-md p-2"
            value={startDate || ""}
            onChange={(e) => setStartDate(e.target.value)}
          />
          <span className="font-bold">→</span>
          <input
            type="date"
            className="border rounded-md p-2"
            value={endDate || ""}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        {/* PDF BUTTON */}
        <button
          onClick={() => handleDownloadPDF(filteredData)}
          className="bg-red-600 text-white px-4 py-2 rounded-lg"
        >
          Download PDF
        </button>
      </div>

      {/* DATA TABLE */}

      {loading ? (
        <div className="w-full flex justify-center items-center py-10">
          <p className="text-gray-500 text-sm animate-pulse">Loading...</p>
        </div>
      ) : filteredData?.length === 0 ? (
        <div className="w-full flex justify-center items-center py-10">
          <p className="text-gray-500 text-sm">No data found</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>S.No</TableHead>
              <TableHead>Waste Type</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Waste Time</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>

          <TableBody>
            {filteredData?.map((item, index) => (
              <TableRow key={item.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>{item.waste_type}</TableCell>
                <TableCell>
                  {item.quantity} {item.unit}
                </TableCell>
                <TableCell>{item.location}</TableCell>

                <TableCell>
                  <span
                    className={`px-3 py-1 rounded-full text-white text-xs
                      ${
                        item.status === "approved"
                          ? "bg-green-600"
                          : item.status === "pending"
                          ? "bg-yellow-600"
                          : "bg-red-600"
                      }`}
                  >
                    {item.status.toUpperCase()}
                  </span>
                </TableCell>

                <TableCell>
                  {new Date(item.waste_time).toLocaleDateString()}{" "}
                  {new Date(item.waste_time).toLocaleTimeString()}
                </TableCell>

                <TableCell className="text-right flex justify-end gap-3">
                  <Pencil
                    size={18}
                    className="cursor-pointer hover:text-blue-600"
                    onClick={() => {
                      setEditConfirm(true);
                      setEditSelectedData({
                        id: item.id,
                        status: item.status,
                        quantity: item.quantity,
                        unit: item.unit,
                      });
                    }}
                  />

                  <Trash2
                    size={18}
                    className="cursor-pointer hover:text-red-600"
                    onClick={() => {
                      setSelectedId(item.id);
                      setDeleteConfirm(true);
                    }}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* DELETE DIALOG */}
      <Dialog open={deleteConfirm} onOpenChange={setDeleteConfirm}>
        <DialogContent>
          <DialogHeader>
            <h3 className="text-lg font-semibold">Confirm Deletion</h3>
          </DialogHeader>

          <p>Are you sure you want to delete this?</p>

          <DialogFooter>
            <Button onClick={() => setDeleteConfirm(false)}>Cancel</Button>
            <Button
              className="bg-red-600 text-white"
              onClick={() => {
                if (selectedId) handleDelete(selectedId);
                setDeleteConfirm(false);
              }}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* EDIT DIALOG */}
      <Dialog open={editConfirm} onOpenChange={setEditConfirm}>
        <DialogContent>
          <DialogHeader>
            <h3 className="text-lg font-semibold">Update Waste</h3>
          </DialogHeader>

          <div className="space-y-3">
            <select
              className="w-full border p-2 rounded-md"
              value={editSelectedData.status}
              onChange={(e) =>
                setEditSelectedData({
                  ...editSelectedData,
                  status: e.target.value,
                })
              }
            >
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>

            <input
              type="text"
              placeholder="Enter quantity"
              className="w-full border p-2 rounded-md"
              value={editSelectedData.quantity}
              onChange={(e) =>
                setEditSelectedData({
                  ...editSelectedData,
                  quantity: e.target.value,
                })
              }
            />

            <input
              type="text"
              placeholder="Enter unit"
              className="w-full border p-2 rounded-md"
              value={editSelectedData.unit}
              onChange={(e) =>
                setEditSelectedData({
                  ...editSelectedData,
                  unit: e.target.value,
                })
              }
            />
          </div>

          <DialogFooter>
            <Button onClick={() => setEditConfirm(false)}>Cancel</Button>

            <Button
              className="bg-yellow-600 text-white"
              onClick={() => handleEdit(editSelectedData)}
            >
              {updateLoading ? "Updating..." : "Update"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ManageReportsTable;
