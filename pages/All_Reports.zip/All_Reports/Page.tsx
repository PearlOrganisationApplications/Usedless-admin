import React, { useState } from "react";
import { Pencil, QrCode, Trash2, Search } from "lucide-react";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import QrModal from "@/components/Modal/QrModal";

interface ReportItem {
  id: number | string;
  name: string;
}

interface AllReportsTableProps {
  active: boolean;
  data: ReportItem[];
  setEditValue: (value: string | null) => void;
  setOpenModal: (open: boolean) => void;
  setSelectedId?: (id: number | string | undefined) => void;
  handleDelete: (id: number | string) => void;
}

const All_Reports_Table: React.FC<AllReportsTableProps> = ({
  active,
  data,
  setEditValue,
  setOpenModal,
  setSelectedId,
  handleDelete,
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ReportItem | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = data?.filter((item) =>
    item?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRowClick = (item: ReportItem) => {
    if (active) {
      setSelectedItem(item);
      setModalOpen(true);
    }
  };

  return (
    <>
      <div className="w-full rounded-xl border p-4 bg-white">
        <div className="flex justify-start items-start mb-4 w-full">
          <div className="w-full sm:max-w-md relative mb-4">
            <Search
              className="absolute left-3 top-2.5 text-gray-500"
              size={20}
            />
            <input
              type="text"
              placeholder={`Search ${active ? "Place" : "Waste Type"}...`}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="w-full overflow-x-auto">
          <Table className="w-full table-fixed sm:table-auto">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[35px] text-[10px] sm:text-sm">
                  #
                </TableHead>
                <TableHead className="text-[10px] sm:text-sm">
                  {active ? "Place Name" : "Waste Type"}
                </TableHead>
                <TableHead className="w-[90px] text-[10px] text-right sm:text-sm">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {filteredData?.map((item, index) => (
                <TableRow key={item.id}>
                  <TableCell className="text-[10px] sm:text-sm">
                    {index + 1}
                  </TableCell>

                  <TableCell className="font-medium text-[10px] sm:text-sm break-words leading-tight">
                    {item.name}
                  </TableCell>

                  <TableCell className="text-right">
                    <div className="flex justify-end gap-0.5 sm:gap-2">
                      {active && (
                        <button
                          className="md:p-2 p-1 cursor-pointer border rounded border-gray-300 flex items-center justify-center group hover:border-green-600"
                          onClick={() => handleRowClick(item)}
                        >
                          <QrCode
                            size={14}
                            className="group-hover:text-green-600"
                          />
                        </button>
                      )}

                      <button
                        className="md:p-2 p-1 cursor-pointer border rounded border-gray-300 flex items-center justify-center group hover:border-blue-600"
                        onClick={() => {
                          setEditValue(item.name);
                          setOpenModal(true);
                          setSelectedId?.(item.id);
                        }}
                      >
                        <Pencil
                          size={14}
                          className="group-hover:text-blue-600"
                        />
                      </button>

                      <button
                        className="md:p-2 p-1 cursor-pointer border rounded border-gray-300 flex items-center justify-center  group hover:border-red-600"
                        onClick={() => handleDelete(item.id)}
                      >
                        <Trash2
                          size={14}
                          className="group-hover:text-red-600"
                        />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}

              {filteredData?.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={3}
                    className="text-center py-4 text-gray-500"
                  >
                    No results found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {active && (
        <QrModal
          open={modalOpen}
          onClose={() => setModalOpen(false)}
          item={selectedItem}
        />
      )}
    </>
  );
};

export default All_Reports_Table;
